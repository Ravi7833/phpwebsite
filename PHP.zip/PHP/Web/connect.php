<?php
$con = mysqli_connect("mysql -h ravi.cq6owmwjzo29.ap-south-1.rds.amazonaws.com -u admin -p ravi","admin","12345678","ravi");
?>